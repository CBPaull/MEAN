// require mongoose
var mongoose = require('mongoose');
// create the schema
var Pokeschema = new mongoose.Schema({
	name: String,
	species: String
});
mongoose.model('Pokemon', Pokeschema);
var Pokemon = mongoose.model('Pokemon'); // We are retrieving this Schema from our Models, named 'Pokemon'
