var mongoose = require('mongoose');
var Pokemon = mongoose.model('Pokemon');
var pokemon = require('../controllers/pokemon.js');

module.exports = function(app){
	app.get('/', function(req, res) {
		pokemon.show(req, res);
		// Pokemon.find({}, function(err, pokemon) {
		// 	if(err) {
		// 		console.log('something went wrong');
  //   		} else { // else console.log that we did well and then redirect to the root route
  //   			console.log('successfully found all pokemon!');
  //   			res.render('index', {Pokemon: pokemon});
  //   		}
  //   	});
	});
	app.get('/pokemon/new', function(req, res) {
		console.log("I'm in pokemon new");
		res.render("new");
	});
	app.get('/pokemon/show/:id', function(req, res) {
		console.log("I'm in Pokemon show");
		console.log(req.params.id)
		pokemon.showid(req, res);

		// Pokemon.findOne({_id: req.params.id}, function(err, pokemon){
		// 	if(err) {
		// 		console.log('something went wrong');
  //   		} else { // else console.log that we did well and then redirect to the root route
  //   			console.log('successfully found a pokemon!');
  //   			res.render('show', {Pokemon: pokemon});

  //   		}
  //   	});
	});
	app.get('/pokemon/edit/:id', function(req, res) {
		pokemon.showedit(req, res);

		// Pokemon.findOne({_id: req.params.id}, function(err, pokemon){
		// 	console.log()
		// 	if(err) {
		// 		console.log('something went wrong');
  //   		} else { // else console.log that we did well and then redirect to the root route
  //   			console.log('successfully found a pokemon!');
  //   			res.render("edit", {Pokemon: pokemon});
  //   		}
  //   	});
	});
	app.post('/pokemon', function(req, res) {
		console.log("POST DATA", req.body);
		pokemon.create(req, res);

		// var pokemon = new Pokemon({name: req.body.name, species: req.body.species});
		// pokemon.save(function(err) {
		// 	if(err) {
		// 		console.log('something went wrong');
  //   		} else { // else console.log that we did well and then redirect to the root route
  //   			console.log('successfully added a pokemon!');
  //   			res.redirect('/');
  //   		}
  //   	});
	});
	app.post('/pokemon/:id', function(req, res) {
		console.log("POST DATA", req.body);
		pokemon.edit(req, res);
		// Pokemon.update({_id: req.params.id}, {$set:{name: req.body.name, species: req.body.species}}, function(err,pokemon){
		// 	if(err) {
		// 		console.log('something went wrong');
  //   		} else { // else console.log that we did well and then redirect to the root route
  //   		console.log('successfully edited a pokemon!');
  //   		res.redirect('/pokemon/show/'+req.params.id);
  //   		}
  //   	});
	});

	app.post('/pokemon/destroy/:id', function(req, res) {
		console.log("POST DATA", req.body);
		pokemon.destroy(req, res);
		// Pokemon.remove({_id:req.params.id}, function(err){
		// 	if(err) {
		// 		console.log('something went wrong');
  //   		} else { // else console.log that we did well and then redirect to the root route
  //   		console.log('successfully released a pokemon!');
  //   		res.redirect('/');
  //   		}
  //   	});    
	});
}